import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    Parent Values: {{parentName}} - {{parentAge}}
    <p>Value changed by child: {{valueChangedByChild}}</p>

    <div>
      <p>Two way data binding - message value: {{message}}</p>
      <input [value]='message' (input)='message=$event.target.value' />
    </div>
    <app-child [outsidechildname] = "parentName" [childAge] = "parentAge" (childChangeParent)="updateTriggeredByChild($event)">How does ng-content work?</app-child>
    <p (click)="setMessage1()">Message1: {{message1}}</p> 
		<p (click)="setMessage2('Text2!')">Message2: {{message2}}</p> 
		<p (click)="setMessage3($event)">Event info: {{message3}}</p> 
    `,
  styles: []
})
export class AppComponent {
  parentName: String = 'Tina';
  parentAge: number = 18;
  valueChangedByChild: String;
  message: String = 'default message';
  
  updateTriggeredByChild(msg: String){
    this.valueChangedByChild = msg;
  }

  private message1; 
	private message2; 
	private message3; 
	setMessage1(){ this.message1 = "Text1"; } 
	setMessage2(text){ this.message2 = text; } 
	setMessage3(evt){ this.message3 = evt.srcElement.tagName; } 


}
