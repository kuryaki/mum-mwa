import { Component, OnInit, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child',
  template: `
    <p>
      Child values: {{childName}} ****** {{childAge}} ----- {{counter}}
    </p>
    <button (click)="updateParent()">Change Parent</button>
    <p>ng-content here: <ng-content></ng-content></p>
    <label (click)='getTargetElement($event)'>Click me!</label>
    <p>using $event to get target element value: {{eventValue}}</p>
  `,
  styles: [],
  inputs: ['childName: outsidechildname', 'childAge'],
  outputs: ['childChangeParent']
})
export class ChildComponent {

  childName: String;
  childAge: number;
  counter: number = 0;
  eventValue: String;

  // @Output()
  childChangeParent: EventEmitter<String>= new EventEmitter<String>();

  updateParent(): void {
    this.counter++;
		this.childChangeParent.emit(`Hello World: ${Math.random()}`); 
	} 

  getTargetElement(evt): void{
    console.log(evt);
    //evt object represents different object in different browser.
    // this.eventValue = evt.srcElement.tagName;
    this.eventValue = evt.target.nodeName;
  }

}
