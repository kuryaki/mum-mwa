import { Component } from '@angular/core';
import { Todo } from './Todo';

@Component({
  selector: 'app-root',
  template: `
    <joke-list></joke-list>
    
    <todo-list>
      <todo [todo]="mytodo">
        <span class="title">{{ mytodo.title }}?</span>
        <h1 class="description">{{ mytodo.description }}</h1>  
      </todo>
    </todo-list>
  `,
  styles: []
})
export class AppComponent {
  title = 'app';
  mytodo: Todo = new Todo("Learning MongoDB", "Already started....");
}
