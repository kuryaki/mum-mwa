import { Component, OnInit, ViewChild, ViewChildren, ContentChild, QueryList, ElementRef, AfterContentInit, AfterViewInit } from '@angular/core';
import { Todo } from './Todo';
import { TodoComponent } from './todo.component';

@Component({
  selector: 'todo-list',
  template: `
  <h4 #header>View Todos</h4>
  <todo *ngFor="let t of todos" [todo]="t">
    <span class="title">{{ t.title }}</span>
    <h1 class="description">{{ t.description }}</h1>
  </todo>
  <h4>Content Todos</h4>
  <ng-content></ng-content>
  `,
  styles: []
})
export class TodoListComponent implements OnInit, AfterContentInit, AfterViewInit {

 

  todos: Todo[] = [
    new Todo("Learning Node", "Start now?"),
    new Todo("Learning Angular", "Start tomorrow?")
  ];

  @ViewChild(TodoComponent) todoViewChild: TodoComponent;
  @ViewChildren(TodoComponent) todoViewChildren: QueryList<TodoComponent>;
  @ViewChild("header") headerEl: ElementRef;
  @ContentChild(TodoComponent) todoContentChild: TodoComponent;

  constructor() {
    console.log(`new - todoViewChild is ${this.todoViewChild}`);
    console.log(`new - todoContentChild is ${this.todoContentChild}`);
  }

  ngOnInit(): void {
    // throw new Error("Method not implemented.");
  }

  ngAfterContentInit() {
    console.log(`ngAfterContentInit - todoContentChild is ${this.todoContentChild}`);
    console.log(this.todoContentChild);
  }

  ngAfterViewInit() {
    console.log(`ngAfterViewInit - todoViewChild is ${this.todoViewChild}`);

    let todos: TodoComponent[] = this.todoViewChildren.toArray();
    console.log(todos);

    console.log(`ngAfterViewInit - headerEl is ${this.headerEl}`);
    this.headerEl.nativeElement.textContent = "Best Todo Machine";
  }
}
