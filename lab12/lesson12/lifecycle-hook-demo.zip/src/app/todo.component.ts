import { Component, OnInit, Input } from '@angular/core';
import { Todo } from './Todo';

@Component({
  selector: 'todo',
  template: `
  <div class="card card-block">
  <h4 class="card-title">
    <ng-content select=".title"></ng-content>
  </h4>
  <p class="card-text"
     [hidden]="data.hide">
    <ng-content select=".description"></ng-content>
  </p>
  <a class="btn btn-primary"
     (click)="data.toggle()">Tell Me
  </a>
</div>
  `,
  styles: []
})
export class TodoComponent  {
  @Input('todo') data: Todo;

}
