import { Component, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  count: number = 10;

  updateFromChild($event){
    this.count++;
  }

  reset(){
    this.count = 0;
  }

}
