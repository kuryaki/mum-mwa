import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { HostelementComponent } from './hostelement.component';
import { TodolistComponent } from './todolist.component';
import { TodoComponent } from './todo.component';
import { TemplatevariableComponent } from './templatevariable.component';
import { TemplatevariablebindingComponent } from './templatevariablebinding.component';


@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    HostelementComponent,
    TodolistComponent,
    TodoComponent,
    TemplatevariableComponent,
    TemplatevariablebindingComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
