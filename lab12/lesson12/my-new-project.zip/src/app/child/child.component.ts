import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {


  @Input()
  parentCount: number;

  @Output()
  change: EventEmitter<number> =  new EventEmitter();

  // @Input('parentCount')
  // count: number;

  constructor() { }

  ngOnInit() {
  }

  updateCount(){
    this.parentCount++;
    this.change.emit(this.parentCount);
  }

}
