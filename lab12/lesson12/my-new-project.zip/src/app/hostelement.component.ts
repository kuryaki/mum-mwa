import { Component, OnInit, ElementRef, HostBinding, HostListener, Renderer, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-hostelement',
  template: `
    <p>
      hostelement works!
    </p>
    <p>
      hostelement works!
    </p>
    <p>
      hostelement works!
    </p>
    <p>
      hostelement works!
    </p>
  `,
  styles: []
})
export class HostelementComponent {

  
  constructor(private _el: ElementRef, private _renderer: Renderer2) {
    // this.ChangeBgColor('red');
  }

  @HostBinding('style.border') border: string;
  
  @HostListener('mouseover') onMouseOver() {
    this.ChangeBgColor('red');
    this.border = '5px solid green';
  }
  @HostListener('click') onClick() {
    window.alert('Host Element Clicked');
  }
  @HostListener('mouseleave') onMouseLeave() {
    this.ChangeBgColor('black');
    this.border = 'none';
  }
  ChangeBgColor(color: string) {
    this._renderer.setStyle(this._el.nativeElement, 'color', color);
  }

 }
