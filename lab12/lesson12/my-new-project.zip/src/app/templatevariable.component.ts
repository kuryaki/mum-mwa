import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-templatevariable',
  template: `
  <div>
    <input name="title" value="Josh" #myName /> 
    <button (click)="sayMyName(myName)">Say my name</button>
  </div>

  `,
  styles: []
})
export class TemplatevariableComponent implements OnInit {
  @ViewChild('myName') myName: ElementRef;

  constructor() { }

  ngOnInit() {
  }

  sayMyName(name) {
    console.log(`My name is ${name.value}`);
    // OR
    console.log(`My name is ${this.myName.nativeElement.value}`);
  }

}
