import { Component, OnInit, ViewChild, ContentChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-templatevariablebinding',
  template: `
    <p #myTemplateParagraph>Template Paragraph</p> 
    Access from Template: {{myTemplateParagraph?.textContent}} 
    <ng-content></ng-content> 
    <button (click)="getData()">Get Paragraphs Data</button> 
  `,
  styles: []
})
export class TemplatevariablebindingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @ViewChild('myTemplateParagraph') myTemplatePObj: ElementRef;
  @ContentChild('myParentParagraph') myParentPObj: ElementRef;
  getData() {
    console.log(this.myTemplatePObj.nativeElement.textContent + '===='+
      this.myParentPObj.nativeElement.textContent);
  }


}
