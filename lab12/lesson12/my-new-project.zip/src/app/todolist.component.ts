import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todolist',
  template: `
    <p>TODO List</p>
    <app-todo *ngFor="let todo of todos">
      {{todo}}
    </app-todo>
  `,
  styles: []
})
export class TodolistComponent implements OnInit {

  todos: String[] = ['Learning NodeJS', 'Learning MongoDB', 'Learning Angular'];

  constructor() { }

  ngOnInit() {
  }

}
