//Fake Async
function asyncFake(data, callback) {
    if (data === 'foo') callback(true);
    else callback(false);
}
asyncFake('bar', function (result) { console.log(result) }); // this callback will be called synchronously! 
console.log('Done');

//Real Async
function asyncReal(data, callback) {
    process.nextTick(function () {
        if (data === 'foo') callback(true);
        else callback(false);
    });
}
asyncReal('bar', function (result) { console.log(result) });
console.log('Done');