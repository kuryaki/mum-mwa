setTimeout(
    function(){
        console.log("world");
    }, 2000
);

console.log("hello");