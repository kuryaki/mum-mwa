// let bar;

// // this has an asynchronous signature, but calls callback synchronously
// function someAsyncApiCall(callback) { callback(); }

// // the callback is called before `someAsyncApiCall` completes.
// someAsyncApiCall(() => {
//   // since someAsyncApiCall has completed, bar hasn't been assigned any value
//   console.log('bar', bar); // undefined
// });

// bar = 1;

process.nextTick(()=> console.log('nexttick'));
setImmediate(() => { console.log('immediate'); }); 
setTimeout(() => { console.log('timeout'); }, 0); 
