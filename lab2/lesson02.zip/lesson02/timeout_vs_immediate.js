/**
 * The order in which the timers are executed will vary depending on the context in which they are called. 
 * If both are called from within the main module, then timing will be bound by the performance of the process 
 * (which can be impacted by other applications running on the machine).
 */

setTimeout(() => {
  console.log('timeout');
}, 0);

setImmediate(() => {
  console.log('immediate');
});


//if you move the two calls within an I/O cycle, the immediate callback is always executed first
const fs = require('fs');

fs.readFile('./config.json', () => {
  setTimeout(() => {
    console.log('timeout');
  }, 0);
  setImmediate(() => {
    console.log('immediate');
  });
});